from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_addition_success():
    response = client.post("/api/v1/add", json={"lists": [[1, 2], [3, 4]]})
    assert response.status_code == 200
    assert response.json() == {"result": [3, 7]}

def test_addition_empty_list():
    response = client.post("/api/v1/add", json={"lists": []})
    assert response.status_code == 200
    assert response.json() == {"result": []}

def test_addition_invalid_data():
    response = client.post("/api/v1/add", json={"lists": "invalid"})
    assert response.status_code == 422  # Unprocessable Entity